#include "equal.h"

void make_all_equal(int N, int Q_add, int Q_compare) {
    // your code here!
}
